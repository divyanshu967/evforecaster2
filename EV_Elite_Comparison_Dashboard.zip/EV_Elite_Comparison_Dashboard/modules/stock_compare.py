import streamlit as st, yfinance as yf, pandas as pd, plotly.express as px
def stock_page():
 st.subheader('Top EV Companies Stock Comparison')
 tickers={'Tesla':'TSLA','BYD':'1211.HK','NIO':'NIO','Rivian':'RIVN'}
 data=[]
 for n,t in tickers.items():
   df=yf.download(t,period='6mo',progress=False)
   if len(df)>0:
     data.append(pd.DataFrame({'Date':df.index,'Close':df['Close'],'Company':n}))
 all_df=pd.concat(data)
 st.plotly_chart(px.line(all_df,x='Date',y='Close',color='Company',title='6-Month Stock Price Comparison'),use_container_width=True)
 latest=all_df.sort_values('Date').groupby('Company').tail(1)
 st.plotly_chart(px.bar(latest,x='Company',y='Close',color='Company',title='Latest Closing Price Comparison'),use_container_width=True)
