import streamlit as st
def chat_page():
 st.subheader('AI Insights Assistant')
 q=st.text_input('Ask about EV market or stocks')
 if q:
   q=q.lower()
   if 'best' in q: st.success('Tesla and BYD are dominant players by market visibility.')
   elif 'region' in q: st.success('Use region pie chart to inspect geographic concentration.')
   else: st.success('Dashboard combines EV demand with stock momentum.')
