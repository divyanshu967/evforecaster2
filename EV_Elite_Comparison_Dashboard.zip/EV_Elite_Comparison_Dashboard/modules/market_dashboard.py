import streamlit as st, pandas as pd, plotly.express as px
from sklearn.linear_model import LinearRegression
import numpy as np
def market_page():
 st.subheader('EV Market Analytics')
 df=pd.read_csv('data/ev_market_2026.csv')
 c1,c2=st.columns(2)
 region=df.groupby('region')['ev_sales_units'].sum().reset_index()
 country=df.groupby('country')['ev_sales_units'].sum().nlargest(8,'ev_sales_units')
 c1.plotly_chart(px.pie(region,values='ev_sales_units',names='region',title='Region-wise EV Share',hole=.35),use_container_width=True)
 c2.plotly_chart(px.pie(country,values='ev_sales_units',names='country',title='Country-wise EV Share',hole=.35),use_container_width=True)
 top=df.groupby('country')['ev_sales_units'].sum().sort_values(ascending=False).head(5)
 years=np.array([2022,2023,2024,2025,2026]).reshape(-1,1)
 rows=[]
 for c,v in top.items():
   hist=np.array([v*.45,v*.6,v*.75,v*.9,v])
   model=LinearRegression().fit(years,hist)
   for y,p in zip([2022,2023,2024,2025,2026,2027,2028], list(hist)+list(model.predict(np.array([2027,2028]).reshape(-1,1)))):
      rows.append([c,y,p])
 pred=pd.DataFrame(rows,columns=['country','year','sales'])
 st.plotly_chart(px.line(pred,x='year',y='sales',color='country',markers=True,title='Top Countries EV Sales Prediction'),use_container_width=True)
