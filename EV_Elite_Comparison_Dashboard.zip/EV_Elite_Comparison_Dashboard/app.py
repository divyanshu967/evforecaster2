import streamlit as st
from modules.market_dashboard import market_page
from modules.stock_compare import stock_page
from modules.ai_chat import chat_page
st.set_page_config(page_title='EV Elite Dashboard',layout='wide')
st.markdown("""<style>
.stApp{background:linear-gradient(135deg,#050816,#0f172a);color:white;}
section[data-testid='stSidebar']{background:#020617;}
div[data-testid='metric-container']{background:#111827;padding:12px;border-radius:14px;}
</style>""",unsafe_allow_html=True)
st.title('🚗⚡ EV Elite Comparison Dashboard')
page=st.sidebar.radio('Navigation',['Home','EV Market Analytics','Top EV Stocks','AI Insights'])
if page=='Home':
 st.subheader('Executive Overview')
 c1,c2,c3=st.columns(3)
 c1.metric('Tracked Stocks','4')
 c2.metric('Charts','6+')
 c3.metric('Dataset','2026 EV Market')
 st.info('Premium dashboard with region/country pies and multi-stock comparison.')
elif page=='EV Market Analytics':
 market_page()
elif page=='Top EV Stocks':
 stock_page()
else:
 chat_page()
